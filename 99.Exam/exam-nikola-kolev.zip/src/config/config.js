module.exports = {
    SECRET: 'as123d1a23s123g12j3kkgj4555a5sd4asd33a4sd53bi1kgf1n1j1i1kv1b1k2m3f4nd5j56fk7123bmgfj'
}